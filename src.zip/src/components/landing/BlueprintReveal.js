"use client";

import { useRef } from "react";
import { clamp, pinnedProgress, useScrollFrame } from "./scroll";

// The blueprint starts hidden behind a radial shadow with only a soft glow at
// its centre. As you scroll, a clear circle grows from the centre outwards
// until the whole drawing is 100% sharp (reached at 80% of the pinned scroll,
// so it stays fully clear for a moment before the section moves on).
export default function BlueprintReveal({ src, alt, trackRef }) {
  const boxRef = useRef(null);

  useScrollFrame(trackRef, (el) => {
    const box = boxRef.current;
    if (!box) return false;
    const raw = clamp(pinnedProgress(el) / 0.8);
    const p = raw * raw * (3 - 2 * raw); // smoothstep

    const { width, height } = box.getBoundingClientRect();
    const half = Math.hypot(width, height) / 2; // centre → corner
    const feather = Math.max(60, half * 0.45);

    box.style.setProperty("--ckl-r", `${(p * half).toFixed(1)}px`);
    box.style.setProperty("--ckl-f", `${feather.toFixed(1)}px`);
    box.style.setProperty("--ckl-p", p.toFixed(4));
    return false;
  });

  return (
    <div ref={boxRef} className="ckl-reveal">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={src} alt="" aria-hidden="true" className="ckl-reveal__blur" />
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={src} alt={alt} className="ckl-reveal__sharp" />
      <div className="ckl-reveal__shadow" aria-hidden="true" />
    </div>
  );
}
