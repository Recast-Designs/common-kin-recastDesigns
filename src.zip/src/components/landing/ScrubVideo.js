"use client";

import { useEffect, useRef, useState } from "react";
import { clamp, pinnedProgress, useScrollFrame } from "./scroll";

// A muted video whose playhead follows the scroll position of `trackRef`.
// Scrolling down moves it forward, scrolling up plays it backwards.
//
// The file is fetched once and played from memory (blob URL) so seeking in
// either direction is instant. The videos in /public/videos are encoded with a
// keyframe on every frame for the same reason — re-encode new videos the same
// way (see README-COMMON-KIN.md) or reverse scrubbing will stutter.
export default function ScrubVideo({
  src,
  trackRef,
  progress = pinnedProgress,
  range = [0, 1],
  className = "",
  label,
}) {
  const videoRef = useRef(null);
  const state = useRef({ shown: 0, ready: false });
  const [loaded, setLoaded] = useState({ for: null, url: null });

  // Load the whole file into memory; fall back to streaming it directly
  useEffect(() => {
    if (!src) return undefined;
    let objectUrl = null;
    let cancelled = false;
    fetch(src)
      .then((res) => (res.ok ? res.blob() : Promise.reject(new Error(res.statusText))))
      .then((blob) => {
        if (cancelled) return;
        objectUrl = URL.createObjectURL(blob);
        setLoaded({ for: src, url: objectUrl });
      })
      .catch(() => {
        if (!cancelled) setLoaded({ for: src, url: src });
      });
    return () => {
      cancelled = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [src]);

  const videoSrc = loaded.for === src ? loaded.url : null;

  function handleMetadata() {
    const video = videoRef.current;
    if (!video) return;
    state.current.ready = true;
    // iOS Safari only paints seeked frames after the video has played once
    const attempt = video.play();
    if (attempt && typeof attempt.then === "function") {
      attempt.then(() => video.pause()).catch(() => {});
    }
  }

  useScrollFrame(trackRef, (el) => {
    const video = videoRef.current;
    const s = state.current;
    if (!video || !s.ready || !Number.isFinite(video.duration)) return false;

    const [from, to] = range;
    const p = clamp((progress(el) - from) / (to - from));
    const target = p * Math.max(0, video.duration - 0.05);

    // Ease towards the target so fast scrolling still looks smooth
    s.shown += (target - s.shown) * 0.18;
    if (Math.abs(target - s.shown) < 0.004) s.shown = target;

    if (!video.paused) video.pause();
    if (!video.seeking && Math.abs(video.currentTime - s.shown) > 0.01) {
      video.currentTime = s.shown;
    }
    return Math.abs(target - s.shown) > 0.004;
  });

  return (
    <video
      ref={videoRef}
      src={videoSrc || undefined}
      className={className}
      muted
      playsInline
      preload="auto"
      disablePictureInPicture
      disableRemotePlayback
      aria-label={label}
      onLoadedMetadata={handleMetadata}
    />
  );
}
